# -*- coding = utf-8 -*-
# @Time: 2022/4/13 8:55
# @Author: 陌言
# @File: 01 hello_world.py
# @SoftWare: PyCharm

import time # 我导入了一个时间模块

print(time.time()) # 在屏幕商打印出从1970年1月1日0:00到现在经过了多少秒
if 10 - 9 > 0:
    # 这行需要缩进，缩进一般四个空格
    print('10大于9')