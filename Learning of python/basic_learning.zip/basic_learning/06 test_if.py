# -*- coding = utf-8 -*-
# @Time: 2022/4/13 14:16
# @Author: 陌言
# @File: 06 test_if.py
# @SoftWare: PyCharm

x = 'abcd'
if x == 'abc':
    print('x的值和abc相等')
else:
    print('x和abc不相等')
