# -*- coding = utf-8 -*-
# @Time: 2022/4/13 11:35
# @Author: 陌言
# @File: 04 chinese_zodiac.py
# @SoftWare: PyCharm

# 记录生肖，根据年份来判断生肖
chinese_zodiac = '猴鸡狗猪鼠牛虎兔龙蛇马羊'

print('狗' in chinese_zodiac)
print('狗' not in chinese_zodiac)
print(chinese_zodiac + 'abcd')
print(chinese_zodiac * 3)