# -*- coding = utf-8 -*-
# @Time: 2022/4/13 9:16
# @Author: 陌言
# @File: 03 network bandwidth.py
# @SoftWare: PyCharm

# 网络带宽计算
print(100/8)

bandwidth = 100
ratio = 8
print(bandwidth/ratio)