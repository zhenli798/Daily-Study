# -*- coding = utf-8 -*-
# @Time: 2022/4/18 13:49
# @Author: 陌言
# @File: 15 sanguo.py
# @SoftWare: PyCharm

# # 读取人物名称
# f = open('name.txt')
# data = f.read()
# print(data.split('|'))
#
# # 读取兵器名称
# f2 = open('weapon.txt')
# i = 1
# for line in f2.readlines():
#     if i % 2 == 1:
#         print(line.strip('\n'))  # strip删除字符串首尾指定字符
#     i += 1
#
# f3 = open('sanguo.txt', 'r', encoding='utf-8')
# print(f3.read().replace('\n', ''))


