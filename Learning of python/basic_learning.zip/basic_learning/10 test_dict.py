# -*- coding = utf-8 -*-
# @Time: 2022/4/16 21:37
# @Author: 陌言
# @File: 10 test_dict.py
# @SoftWare: PyCharm

dict1 = {}
print(type(dict1))
dict2 = {'x':1, 'y':2}
dict2['z'] = 3

print(dict2)
